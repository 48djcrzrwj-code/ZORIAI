// ZORIAI server: receives a screenshot / mission name / follow-up question
// and asks Claude through the Anthropic API. The API key stays here, never in the browser.
const { M, buildSystem } = require("../data.js");

const MODEL = process.env.ZORIAI_MODEL || "claude-sonnet-5-5";
const MAX_IMAGE_B64 = 6_000_000; // ~4.5MB image
const hits = new Map(); // simple per-IP limit (per server instance)
const LIMIT_PER_HOUR = Number(process.env.ZORIAI_LIMIT_PER_HOUR || 30);

function limited(ip) {
  const now = Date.now();
  const list = (hits.get(ip) || []).filter((t) => now - t < 3600_000);
  list.push(now);
  hits.set(ip, list);
  return list.length > LIMIT_PER_HOUR;
}

module.exports = async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });
  if (!process.env.ANTHROPIC_API_KEY) return res.status(500).json({ error: "missing key" });

  const ip = String(req.headers["x-forwarded-for"] || "").split(",")[0].trim() || "x";
  if (limited(ip)) return res.status(429).json({ error: "rate" });

  const body = typeof req.body === "string" ? JSON.parse(req.body || "{}") : req.body || {};
  const gender = body.gender === "f" ? "f" : "m";
  const clip = (s, n) => String(s || "").slice(0, n);

  let messages;
  if (body.image) {
    if (typeof body.image !== "string" || body.image.length > MAX_IMAGE_B64)
      return res.status(413).json({ error: "image too large" });
    const extra = clip(body.extra, 500);
    messages = [{
      role: "user",
      content: [
        { type: "image", source: { type: "base64", media_type: "image/jpeg", data: body.image } },
        { type: "text", text: "צילום מסך מהמשחק. זהה את המשימה והסבר אותה." + (extra ? "\nשאלה נוספת של השחקן: " + extra : "") },
      ],
    }];
  } else if (body.mission) {
    const m = M.find((x) => x[1] === body.mission);
    if (!m) return res.status(400).json({ error: "unknown mission" });
    messages = [{ role: "user", content: `הסבר לי בפירוט את המשימה "${m[1]}" (פרק ${m[0]}).` }];
  } else if (Array.isArray(body.history) && body.history.length) {
    messages = body.history.slice(-10)
      .filter((x) => x && (x.role === "user" || x.role === "assistant"))
      .map((x) => ({ role: x.role, content: clip(x.content, 6000) }));
    while (messages.length && messages[0].role !== "user") messages.shift();
    if (!messages.length || messages[messages.length - 1].role !== "user")
      return res.status(400).json({ error: "bad history" });
  } else {
    return res.status(400).json({ error: "nothing to explain" });
  }

  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 1800,
        system: buildSystem(gender),
        messages,
      }),
    });
    const d = await r.json();
    if (!r.ok) {
      console.error("Anthropic error", r.status, d && d.error);
      return res.status(r.status === 429 ? 429 : 502).json({ error: "upstream" });
    }
    const text = (d.content || []).filter((c) => c.type === "text").map((c) => c.text).join("\n");
    return res.status(200).json({ text });
  } catch (e) {
    console.error(e);
    return res.status(502).json({ error: "upstream" });
  }
};
