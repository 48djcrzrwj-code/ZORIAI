/* ZORIAI data – shared by the page and the server */
const CH=[
 {n:1,he:"פרק 1 · Just Like Paradise",area:"Leonida Keys"},
 {n:2,he:"פרק 2 · Paradise Lost",area:"Port Gellhorn"},
 {n:3,he:"פרק 3 · Tits Ass Drug Money",area:"Vice City"},
 {n:4,he:"פרק 4 · Vice City, Baby",area:"Vice City"},
 {n:5,he:"פרק 5 · Top of the World, Ma",area:"Vice City"}];
const M=[
[1,"Prologue","L","","משחקים בלוסיה בכלא: הולכים אחרי הסוהרת לפגישה עם היועצת, ובפלאשבק מבצעים שוד."],
[1,"Gone Fishing","J","","ג׳ייסון ודוני מבריחים: אוספים את החבילות שהמטוס של דוני הפיל, מצילים אותו מה־Kingfishers וטסים חזרה למרינה של בריאן."],
[1,"Gear Up","J","Pick Up Another Gun","קונים רובה ארוך (Longarm) ב־Ammu-Nation. פותח חנויות נשק וניהול Loadout."],
[1,"Just a Scratch","J","Fix Your Car","לוקחים את ה־Ganado של ג׳ייסון למוסך ומתקנים אותו."],
[1,"Lab Fees","J","Collect Brian's Rent","גובים שכר דירה מדייר של בריאן. פותח את המחסן של בריאן (Drop-Off)."],
[1,"Unwanted Attention","J","Go See Cal","נפגשים עם קאל ונוסעים איתו ל־Hamlet. פותח את Pay 'n' Spray וסורק המשטרה."],
[1,"Pipework","J","Collect Mandy's Rent","הולכים למנדי: עבודת אינסטלציה וגביית שכר דירה."],
[1,"Hey Arnold!","J","Meet Brian","בריאן, ג׳ייסון וקאל מחפשים ברוקר."],
[1,"Island Dreams","J","Work for Kenton","עבודה אצל קנטון: משימת צלילה ראשונה. פותח חיפוש באתרי צלילה."],
[1,"Feng Shui","J","Meet Cal","עוזרים לקאל להזיז רהיטים."],
[1,"Coming Home","JL","Lucia's Release","אוספים את לוסיה כשהיא משתחררת מהכלא. לפני כן אפשר לקנות פרחים, שרשרת ובגדים ללוסיה (אופציונלי)."],
[1,"Buck Me","JL","Set Up Bank Account","פותחים חשבון בנק באפליקציית BuckMe. אחרי זה אפשר להפקיד מזומן בכספומט."],
[1,"Clean Up After Donnie","J","Donnie's Drop","אוספים חבילה מנקודת ההטלה של דוני."],
[1,"Down to Earth","JL","Meet Brian","טיסת הברחה עם לוסיה: מורידים חבילות על הסמנים במים. אחרי המשימה כדאי לקבל את הצעת המדיטציה של לוסיה במרפסת (לא זמינה אחרי פרק 1)."],
[1,"Clear Skies","J","Join Donnie On A Job","ג׳ייסון ודוני מבקרים כנופיית אופנוענים."],
[1,"Day Release","JL","Meet Mattia & Kat","בילוי לילי עם מאטיה וקאט."],
[1,"Swamped","J","Meet Brian","פגישה עם בריאן ולורי מול ה־Kingfishers בגלל הסכסוך של דוני."],
[1,"Don Gone","J","Head to Donnie's Trailer","בודקים בקרוואן של דוני מה קרה לו. אחריה מופיעה משימת Donnie's Lost Drugs."],
[1,"Recalibration","JL","Talk to Lucia","מבלים עם קאל ומתקדמים לקראת העבודה הבאה של מאטיה."],
[1,"Tourist Trap","JL","Take Up Mattia's Offer","אוספים תיק מלוקר במרכז המבקרים, שורדים שוטרים מושחתים ובורחים בסירה. לפני המשימה כדאי להעביר לפחות 5,000$ ל־Family Savings."],
[1,"Home Sweet Home","L","","לוסיה חוזרת הביתה לקחת את המחבוא של ג׳ייסון ומתמודדת עם מה שקרה."],
[1,"Discharge Time","L","","לוסיה בודקת מה שלום ג׳ייסון בבית החולים. המשימה מובילה לפרק 2."],
[2,"What's in the Bag?","L","","פתיחת הפרק ב־Port Gellhorn. אחריה: Take Care of Jason (משחקים אחות) ו־Overnight Charges (מדברים עם לינדה, מנהלת המוטל)."],
[2,"Ambulance Chaser","L","Move the Ambulance","לוסיה נפטרת מהאמבולנס."],
[2,"Just Moved In","L","","לוסיה מסתדרת במקום החדש ויוצאת לקניות."],
[2,"Girls' Trip","L","Find Painkillers","לוסיה יוצאת לחפש משככי כאבים ומכירה חברה חדשה."],
[2,"Moses","L","Take A Vehicle to Moses","פוגשים את מוזס ומביאים לו רכב. לוסיה מקבלת Slim Jim לפריצת רכבים. אחריה: New Look ו־How Do I Look?"],
[2,"Daily Driver","L","Steal the Crawler for Moses","גונבים את ה־Crawler ומביאים למוזס."],
[2,"Slam Dunk","L","Find Painkillers","עובדים עם דאנק כדי להשיג משככי כאבים. אם דאנק לא מתקשר, השלימו קודם את Painkiller Supplier ו־Behind on Payments."],
[2,"Breakfast Run","JL","Check on Jason","ג׳ייסון ולוסיה יוצאים לוופלים."],
[2,"Coffee Break","JL","","מתכננים את הצעד הבא. בפרק זה זמינות גם משימות צד: Thrillbillies, Hit Avery Pawn, Hit Kingpin Bowling."],
[2,"Afternoon Delight","JL","Rob Vicki's Boss","מבקרים במועדון החשפנות ושודדים את הבוס של ויקי."],
[2,"Checking Out","JL","Move to Vice City","חוזרים למוטל, נלחמים בתוקפים ובורחים לכיוון Vice City. לפני המשימה כדאי לחסוך לפחות 15,000$."],
[3,"Welcome to Vice City","JL","","מגיעים ל־Vice City ופוגשים את דרה׳קוואן."],
[3,"Dealer's Choice","J","Go See Dre'Quan","ג׳ייסון מבצע עסקת סמים שדרה׳קוואן סידר."],
[3,"Meet the Heders","JL","Meet Brian & Lori","דאבל דייט עם בריאן ולורי."],
[3,"Dubious Provenance","JL","Visit the Antique Store","הולכים לחנות העתיקות ומבצעים את העבודה."],
[3,"Mami Knows Best","L","Catch Up With Mia","לוסיה פוגשת את מיה, בת משפחה. אחריה אפשר לשלוח כסף ללורנה."],
[3,"South Leonida Real Estate","L","Meet Mia","לוסיה נתקלת בארגון M7 בעבודה עם מיה."],
[3,"Tyrone","J","","ג׳ייסון מבקש עבודה מטיירון."],
[3,"Here, Kitty Kitty","J","Speak with Tyrone","ג׳ייסון מחפש את צ׳ארלס במשימה של טיירון."],
[3,"Car Service","L","Steal The Car for Raul","לוסיה גונבת רכב עבור ראול."],
[3,"Top Billing","JL","Watch the Real Dimez","הולכים עם דרה׳קוואן להופעה של Real Dimez."],
[3,"Boobie Time","J","Talk to Boobie","ג׳ייסון מסיע את בובי ליעדים ומשלים את המשימה שלו."],
[3,"First Impressions","JL","Meeting with Raul","פגישה ראשונה עם ראול ותחילת עבודה עם הצוות שלו."],
[3,"Caught Slipping","JL","","מונעים פריצה."],
[3,"Crosstown Traffic","L","Meet Raul","לוסיה עוקבת אחרי חבר כנופיה (במקביל לג׳ייסון: Meet Karim)."],
[3,"Credit Check","JL","Meet Raul's Crew","ראול מזמין לבסיס שלו ומכיר את האנשים."],
[3,"Clonin' Keys, Makin' GS","JL","Steal the Zorrusso for Randy","גונבים רכב יוקרה (Zorrusso) עבור רנדי. דורש שכפול מפתח – רכב Keyless."],
[3,"Sinfrontera National Bank","JL","Scope Out the Bank","סיור מקדים בבנק – הכנה ראשונה ל־The Cartel Heist."],
[3,"Security Expert","JL","","פוגשים את ניקול ומשלימים את הכנות האבטחה לשוד."],
[3,"Ride or Die","J","Meet Dre'Quan","ג׳ייסון עוזר לדרה׳קוואן."],
[3,"Company Property","JL","Meet Brian","עוזרים במשלוח נשק (הכנה לשוד הקרטל)."],
[3,"The Missing Link","L","Meet Andrea","לוסיה הולכת לקרב תרנגולים ופוגשת אנשי קשר."],
[3,"Safe Word","L","Steal the Practice Safe","גונבים כספת אימון ולוסיה לומדת לפרוץ כספות."],
[3,"Cooties","L","Shoot the Music Video","מצלמים קליפ."],
[3,"Bricked Up","JL","Return to the Apartment","ג׳ייסון ולוסיה עושים עבודה בשביל בובי."],
[3,"Hidden Charges","JL","Meet at the Planning Room","נפגשים בחדר התכנון ומכינים את חומרי הנפץ לשוד."],
[3,"The Cartel Heist","JL","Start the Heist","שוד הבנק עם הצוות של ראול – סיום פרק 3."],
[4,"Ocean Beach","JL","","מתמקמים ב־Vice City. אחריה: Another Life ו־Pool Day."],
[4,"Another Life","L","","לוסיה חושבת על העבר שלה."],
[4,"Company Cars","JL","Speak to the Concierge","מדברים עם הקונסיירז׳ ומקבלים רכבים חדשים."],
[4,"Lawyer Up","JL","Meet Abe Gonzalez","פוגשים את עורך הדין אייב גונזלס. אחר כך צריך לשלם לו (Pay Abe's Fee)."],
[4,"Party Hard","JL","Work Personal Security","אבטחה אישית לסלבריטי במסיבה."],
[4,"Heavy Lifting","JL","Bring Raul the Hard Drive","מביאים לראול את הכונן הקשיח."],
[4,"Photo/Shoot","JL","Shoot a Promo","צילומי פרומו עם דרה׳קוואן."],
[4,"Making Gainz","L","Meet Raul","לוסיה מתחילה משימת כושר שקשורה לתוכנית של ראול (VCIA). אחריה Blood Sweat and Gear."],
[4,"Watch It","J","Meet Dre'Quan","ג׳ייסון ודרה׳קוואן פוגשים בעל מועדון."],
[4,"Cash Injections","L","Hang Out With Nate","לוסיה עוזרת לנייט (קודם: Call Nate)."],
[4,"Amateur Hour","L","Workout","לוסיה עוזרת לסיסקו להתעמת עם במאי."],
[4,"Dirty Work","JL","Deal with Raina","מטפלים בריינה וממשיכים בהכנות לנמל התעופה."],
[4,"Too Much Baggage","J","Scope Out the Airport","ג׳ייסון עובד כסבל מזוודות וסורק את נמל התעופה."],
[4,"Adventures in Babysitting","J","Work Security for Andrés","אבטחה לאנדרס במועדון לילה."],
[4,"Fresh Evidence","J","Meet Dre'Quan","גונבים חומר סחיטה עם דרה׳קוואן."],
[4,"Power Play","L","Help Kordell's Crew","אוספים מודיעין ל־VCIA Takedown."],
[4,"Child's Play","JL","Rescue Rafa from Kidnappers","מצילים את רפא מחוטפים (קודם: Rafa's Kidnapping)."],
[4,"Headliners","JL","Help With The Launch Party","מסיבת השקה והופעה של Real Dimez ב־VYB."],
[4,"Close Surveillance","J","Spy on the Bodybuilders","מרגלים אחרי מטרות עם רחפן ריגול."],
[4,"Delivery Method","J","Help Andrea","ג׳ייסון בעבודה סמויה."],
[4,"Team Building","L","Meet Kordell","לוסיה מוכיחה את עצמה מול הצוות של קורדל."],
[4,"Fully Catered","JL","Steal a Catering Truck","גונבים משאית קייטרינג לפעולה בנמל התעופה."],
[4,"VCIA Takedown","JL","Start the Airport Heist","שוד נמל התעופה."],
[4,"Sunset","JL","Stop by the Front Desk","מחפשים תשובות אחרי השוד (קודם: Tie Up Loose Ends ו־Call Valentina Back)."],
[4,"Starting From Zero","JL","","אירועי הסיום של פרק 4."],
[5,"Bird in the Hand","JL","","גונבים את הרכב שדרוש לפעולה הבאה."],
[5,"Taking Liberties","JL","","מתכננים תוכנית חדשה."],
[5,"VC Baby","JL","Talk to Mattia","מישהו מבקש עזרה."],
[5,"Doggie Bag","JL","Meet Vinny","מחפשים סחורה מוברחת."],
[5,"Operation Savage Glory","JL","","משחזרים משלוח. אחריה: Honest Abe, Unfinished Business ו־Pay Abe's Fee."],
[5,"Protective Custody","JL","Meet with Abe","ג׳ייסון ולוסיה עובדים יחד ברצף שלפני הסוף."],
[5,"The End of the Road","JL","","משימת הסיום של הסיפור."]];
const SIDE=`משימות צד ופעילויות שכדאי להכיר:
- פרק 1 (אפשר לפספס): Get Shirley's Rum ו־Steal the Scooter – לסיים לפני שעוזבים את Leonida Keys. Find the Lost Drugs, Clock Out, Building a Life, Save for the Future.
- פרק 2: Check Out McKittrick Farm ו־Collect Chemicals (קייל), Thrillbillies ו־Twist Wrist, Smash, Grab (בילי), Veteran Hunted (ג׳ייסון בלבד, ברט), Hit Avery Pawn, Hit Kingpin Bowling, Impounded Vehicle, Prepare for Vice City.
- פרק 3: Join a Street Race, Bumper to Bumper, Race Against Yago (מוגבל בזמן, סמל שעון חול), Brother to Brother (יאגו). עבודות התכשיטים של יאסמני (Richardson Jewelry, Donovan Banks & Co, Casa de Empeno). Buddy? (סיום קייל), Mall Rats (בילי), Encrypted Hard Drive, Send Money to Lorena.
- פרק 4: It's A Date!, Bad Driver! (פליפה), Attend Eddie Acosta's Party, This is a Free Call From… (לוסיה, מוגבל בזמן), That's Where The Money Is… (פותח שודי כספות גדולים).
- Strangers & Freaks: קירק (Skunk Ape בלילה, Tree Effigies, Mr. Mangrove), אלבן (תיירים נעדרים), Pilot Pete (משלוחים מתוזמנים לג׳ייסון – כל 7 החבילות לפני שנגמר הזמן, 20,000$), רנדי (Wish List), טיירון (Kitty Litter Labs, Spin On This), Dr. Merle, Freddie ועוד.
טיפים כלליים: אין Replay למשימות ואין מדליות זהב – שמרו ידנית בתחילת ובסוף כל פרק. משימה מוגבלת בזמן מסומנת בשעון חול. אם משימה לא מופיעה – עשו משימות אחרות או לכו לישון. הסדר יכול להשתנות קצת.`;
const G=[
 ["חמש דקות לפני {שאתה מתחיל|שאת מתחילה}",["פריסת מקשים: <code>Settings → Control Scheme → Classic</code>. ריצה ב־X כמו ב־GTA 5.","מינימפה קבועה: <code>UI → Navigation → Minimap: On</code>.","כתוביות גדולות: <code>UI → Subtitles & Captions</code>. {שנה|שני} את Size, Speaker Names ו־Background.","מצלמה: {הורד|הורידי} Motion Blur {ונסה|ונסי} Camera Shake: Off. שינוי אחד בכל פעם.","יחידות מוכרות בישראל: Metric, Kilograms, Celsius, 24 Hour."]],
 ["מקשים ב־Classic (PS5)",["ריצה X · טיפוס □ · מגע ○ · התכופפות L3","כיוון/ירי L2/R2 · מחסה R1 · נרתיק L1 · אינטראקציה △","טלפון: חץ למעלה · יעד/מינימפה: חץ למטה · מפה: משטח המגע","פוקוס: L3+R3 · פוקוס בקרב: תוך כדי L2 {לחץ|לחצי} L3+R3"]],
 ["פוקוס",["בחקירה: מדגיש פריטים, רמזים ומקורות רעש.","בקרב: מאט את הזמן ומבליט נקודות פגיעה.","{ממלא|ממלאת} אותו בשינה, מקלחת וקפה. {מגדיל|מגדילה} אותו במטווח, דיג, גולף וביליארד.","Buff הוא חיזוק זמני, עליית רמה נותנת יותר קיבולת. {בדוק|בדקי} ב־Fitness."]],
 ["חיים וסיבולת",["Health: אימוני כוח. Stamina: הליכון, אופניים, ריצה, שחייה, שק אגרוף.","{פתח|פתחי} Fitness, {בדוק|בדקי} את Workout Window {וסיים|וסיימי} את האימון עד הסוף.","אחרי אימון: שייק או חטיף חלבון ומנוחה. {עקוב|עקבי} אחרי כל דמות בנפרד."]],
 ["הפרופיל הפלילי",["Professional: התגנבות ומינימום נפגעים. Hardened: כוח בלי להרוג.","Violent ו־Psycho: הרג ואלימות. המשטרה יורה מהר יותר.","Irredeemable קבוע ואי אפשר לחזור ממנו.","{בדוק|בדקי} בלשונית Jason & Lucia במפה."]],
 ["עבודה בזוג",["תפריט שותף: {החזק|החזיקי} חץ ימינה. החלפת דמות: חץ ימינה + R1.","Invite כדי להיפגש, Split Up כדי להיפרד. האפשרויות נפתחות עם הסיפור.","כדי לשמור על היחסים, {ענה|עני} להודעות {ועשה|ועשי} פעילות משותפת."]],
 ["התגנבות בלי להרוג",["{תצפת|תצפתי} מבחוץ: כניסות, אנשים, מצלמות ודרך יציאה.","דלת לבנה נגישה. דלת אדומה מחוברת לאזעקה.","ירי בגפיים מנטרל בלי להרוג (סמן צהוב).","אזעקה ומצלמה הן שני דברים נפרדים. הקלטה בענן לא נמחקת."]],
 ["ציוד ואפוד",["{החזק|החזיקי} L1 לגלגל הציוד. R1 מחליף בין Weapons ל־Items.","אפוד: Items ← Body Armor ← X. מופיע מד כחול מעל החיים.","מילוי חיים לא מחדש אפוד. מה שבתא המטען לא נמצא {עליך|עלייך}."]],
 ["גניבת רכבים עם WAiNK",["{החזק|החזיקי} חץ למעלה ← WAiNK ← {כוון|כווני} לרכב ← {החזק|החזיקי} R1.","Alarm: שבירת חלון מפעילה אזעקה. Keyless: צריך משכפל מפתח.","Advanced Tracker מדווח למשטרה. בהתחלה {העדף|העדיפי} רכב פשוט."]],
 ["משטרה",["הכוכבים הם עוצמת המרדף. מתחתם: קולב = הלבוש מזוהה, ראש = המראה מזוהה.","{שבור|שברי} קשר עין, ואז {החלף|החליפי} את מה שמזוהה (בגדים או רכב).","פגיעה בשוטרים מסלימה את המרדף. {השאר|השאירי} את Heat Indicators פעיל."]],
 ["כסף ושלל",["מזומן {שעליך|שעלייך} הולך לאיבוד במוות או במעצר. {הפקד|הפקידי} בכספומט אחרי Buck Me.","Marked Bills ותכשיטים צריך למכור: <code>Map Index → Robberies → Drop-offs – Goods</code>.","התשלום מגיע לפעמים אחרי כמה ימים במשחק, לתיבת הדואר.","נשק שנעלם: ארון הנשקים הירוק ב־Ammu-Nation ← Manage Weapons."]],
 ["שדרוגי נשק",["<code>Ammu-Nation → Owned Weapon → Modify</code>.","משתיק לא מבטל עדים, מצלמות או אזעקות.","השדרוגים לא משותפים לשתי הדמויות."]],
 ["רכב, מפה וטלפון",["רכב מהרחוב הוא לא רכב אישי. רכב אישי מופיע ב־Map Index → Personal.","חץ שמאלה: רדיו, אורות וחלונות.","מבנה בכחול כהה במפה = יש כניסה. Brief מציג הוראות {שפספסת|שפספסת}, Help מסביר מערכות."]],
 ["{נתקעת|נתקעת}?",["X לא מריץ? {בדוק|בדקי} אם נבחרה Classic או Default.","הוראות נחתכות? Display → Safe Zone.","חנות סגורה? {בדוק|בדקי} את השעה בטלפון.","אין אפשרות לרשום רכב? כנראה זה עוד נעול בסיפור."]]];
const T={
 intro:"{מצלם|מצלמת} את המסך {ומקבל|ומקבלת} הסבר מפורט בעברית: מה המשימה, מה {עושה|עושה} שלב אחרי שלב, ואיזה מקשים ללחוץ.",
 tabScan:"📷 {צלם|צלמי} משימה",dropBig:"{הוסף|הוסיפי} צילום",
 dropTxt:"{לחץ|לחצי} כאן כדי לבחור מהגלריה, או {צלם|צלמי} עם הכפתור למטה. כדאי שיופיעו שם המשימה או ההוראה הצהובה בתחתית המסך.",
 cam:"📷 {צלם|צלמי} עכשיו",gal:"🖼️ {בחר|בחרי} מהגלריה",extraL:"{רוצה|רוצה} לשאול משהו ספציפי? (לא חובה)",
 go:"{תן|תני} לי הסבר על המשימה",reset:"{נקה|נקי} צילום",
 s1:"{עצור|עצרי} את המשחק או {חכה|חכי} להוראה על המסך, {וצלם|וצלמי} את הטלוויזיה בטלפון.",
 s3:"{תקבל|תקבלי} הסבר בעברית: מה המטרה, צעד אחר צעד, טיפים ומקשים ב־PS5, ודברים שאסור לפספס.",
 s4:"{אתה יכול|את יכולה} להמשיך לשאול שאלות על אותה משימה מתחת לתשובה.",
 note:"{שים|שימי} לב:",
 qph:"חיפוש לפי שם משימה או דמות…",extraPh:"למשל: איפה {אני מוצא|אני מוצאת} את הכלי? איך לא להיתפס?",
 fuPh:"למשל: איך {אני בורח|אני בורחת} מהמשטרה במשימה הזו?",ask:"{שאל|שאלי}",
 none:"לא נמצאה משימה. {נסה|נסי} מילה אחרת.",
 noClaude:"החיבור ל־Claude לא זמין בתצוגה הזו. {פתח|פתחי} את ZORIAI בעמוד שלה ב־claude.ai.",
 rate:"יותר מדי בקשות. {חכה|חכי} דקה {ונסה|ונסי} שוב.",deny:"לא ניתנה הרשאה ל־Claude. {אשר|אשרי} את הבקשה {ונסה|ונסי} שוב.",
 fail:"משהו השתבש. {נסה|נסי} שוב.",noImg:"שליחת תמונות לא זמינה כרגע. {אתה יכול|את יכולה} לבחור משימה מהרשימה.",
 more:"{תן|תני} לי הסבר מפורט שלב אחרי שלב",fuL:"שאלת המשך"};
const charName={J:"ג׳ייסון",L:"לוסיה",JL:"ג׳ייסון ולוסיה"};
function gText(t,gender){return t.replace(/\{([^|{}]*)\|([^|{}]*)\}/g,(_,a,b)=>gender==="f"?b:a)}
function buildSystem(gender){
  const strip=h=>h.replace(/<[^>]+>/g,"");
  const missions=M.map((m,i)=>`${m[0]}.${M.filter((x,j)=>x[0]===m[0]&&j<=i).length} ${m[1]}${m[3]?" ("+m[3]+")":""} [${charName[m[2]]}]: ${m[4]}`).join("\n");
  const guide=G.map(x=>`# ${gText(x[0],gender)}\n- `+x[1].map(y=>strip(gText(y,gender))).join("\n- ")).join("\n");
  return `אתה ZORIAI, עוזר מומחה ל־GTA 6 (Grand Theft Auto VI, יצא ב־19 בנובמבר 2026) לשחקני PS5 ישראלים. ענה תמיד בעברית פשוטה וידידותית, ופנה לשחקן ${gender==="f"?"בלשון נקבה יחידה (את, תלחצי, תצלמי, שימי לב)":"בלשון זכר יחיד (אתה, תלחץ, תצלם, שים לב)"} לאורך כל התשובה. השאר שמות משימות, תפריטים ופריטים באנגלית כמו במשחק.
ענה רק על שאלות שקשורות ל־GTA 6. אם שואלים על משהו אחר, הסבר בנימוס שאתה עוזר רק במשחק.
מאגר הידע שלך הוא המקור המהימן לשמות משימות, סדר, דמויות ומטרות:
=== משימות הסיפור (פרק.מספר שם (תווית במפה) [דמות]: מטרה) ===
${missions}
=== ${SIDE}
=== מדריך כללי (מקשים בפריסת Classic) ===
${guide}
=== סוף המאגר ===
כללים:
1. אם יש תמונה – קרא בה כל טקסט (שם משימה, הוראה צהובה בתחתית, סמני מפה, הודעות טלפון, תפריט) והתאם למשימה מהמאגר. אם לא בטוח, תן את 1–2 ההתאמות הסבירות ואמור מה ראית.
2. פרטים שלא נמצאים במאגר: אל תמציא מיקומים, סכומים או שמות. אפשר להסיק מההוראה שבתמונה ולתת עצות מהמדריך הכללי, ולציין "טיפ כללי".
3. בלי ספוילרים מעבר למשימה הנוכחית.
פורמט התשובה (Markdown פשוט):
## <שם המשימה> – <פרק>
שורה: מי משחק ואיפה זה בסיפור.
## מה המטרה
## שלב אחרי שלב
רשימה ממוספרת, עם המקשים הרלוונטיים ב־PS5 Classic.
## טיפים
## לא לפספס
(רק אם יש משהו: חיסכון כסף, משימה מוגבלת בזמן, שמירה ידנית וכד׳.)
אם התמונה היא לא משימה אלא תפריט/הודעה/מצב במשחק – הסבר מה רואים ומה לעשות, בלי המבנה הזה.`;
}
if(typeof module!=="undefined")module.exports={CH,M,G,T,SIDE,buildSystem,gText};
